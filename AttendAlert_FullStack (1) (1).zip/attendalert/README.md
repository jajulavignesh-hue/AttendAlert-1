# AttendAlert: Smart Attendance with Early-Warning Alerts

A three-tier web application. Browser UI -> Express REST API -> SQLite database.

```
public/            Presentation tier: index.html, css/styles.css, js/{main,api,ui}.js (ES modules)
server/app.js      HTTP tier: Express routes, security headers, error mapping
server/service.js  Business tier: validation, authorisation, SQL (framework-independent)
server/auth.js     scrypt password hashing, signed expiring tokens
server/db.js       SQLite schema (foreign keys, UNIQUE/CHECK constraints) and demo seed
shared/attendance.js  Percentage / risk / recovery rules used by server, browser and tests
tests/             Automated unit + service/integration tests (node:test)
```

## Run

Requires **Node.js 22.13 or newer** (uses the built-in `node:sqlite`, so there is no native build step).

```
npm install
npm start          # http://localhost:3000
npm test           # 18 automated tests
```

Optional environment variables: `PORT`, `DB_FILE` (default `data/attendalert.db`), `TOKEN_SECRET`
(set this in production so sessions survive restarts). Delete the `.db` file to reset the demo data.

### Demo accounts (seeded on first start)
| Role    | Username                      | Password     |
|---------|-------------------------------|--------------|
| Mentor  | `mentor`                      | `mentor123`  |
| Student | any roll no. e.g. `23A91A0003` (or `student`) | `student123` |

## Features
- Role-based login: mentors manage everything; students see only their own record
- Subject-wise attendance, 1 or 2 consecutive periods, Present / Absent / Late (Late counts as attended)
- Risk tiers: Safe (75%+), Warning (65-74.9%), Critical (<65%); percentages round down, so 74.96% is never shown as 75%
- Risk alerts naming the subjects below 75%, plus mentoring notes
- Recovery estimator: consecutive classes needed to reach 75%, **and how many classes can safely be missed**
- Add / remove students (each gets a login), attendance history, CSV export, print report

## REST API
| Method & path | Who | Purpose |
|---|---|---|
| POST `/api/login` | public | returns a signed token |
| GET `/api/me`, `/api/subjects` | any user | session info, subject list |
| GET `/api/students` | any user | mentor: all; student: own record only |
| POST / DELETE `/api/students[/:id]` | mentor | add (with initial password) / remove |
| POST `/api/attendance` | mentor | save attendance for a date, subject and 1-2 periods |
| GET `/api/attendance/log` | mentor | recent history with absentees |
| POST `/api/notes`, GET `/api/students/:id/notes` | mentor | mentoring interventions |
| GET `/api/report.csv` | mentor | CSV export |

## Security
- Passwords hashed with scrypt and a per-user salt; constant-time comparison; no plaintext anywhere
- HMAC-signed tokens with an 8-hour expiry; role checked on the server for every protected route
- Login lock-out after 5 failed attempts (15 minutes); unknown users take the same time as wrong passwords
- All SQL uses parameterised statements; strict server-side validation (dates, periods, statuses, names, roll numbers)
- Database constraints prevent duplicate attendance (UNIQUE) and orphaned rows (foreign keys, cascade)
- UI escapes all output (XSS); CSP, `X-Frame-Options`, `nosniff` headers; CSV export neutralises spreadsheet formula injection
- Demo passwords are for demonstration only. Change them before any real use.

## Testing
`npm test` runs 18 tests covering: percentage/risk/recovery maths (exhaustively checked for every combination up to 40 classes), password hashing, token tampering and expiry, login and lock-out, role-based access, attendance saving, duplicate protection and validation, student add/remove, notes, history, and CSV injection.
