// All network access lives here. The token is kept in sessionStorage (cleared when the tab closes).
let token = sessionStorage.getItem('aa_token') || '';
export const session = {
  get: () => token,
  set(t) { token = t; t ? sessionStorage.setItem('aa_token', t) : sessionStorage.removeItem('aa_token'); },
};

async function call(path, { method = 'GET', body, raw = false } = {}) {
  const res = await fetch(`/api${path}`, {
    method,
    headers: { ...(body && { 'Content-Type': 'application/json' }), ...(token && { Authorization: `Bearer ${token}` }) },
    body: body && JSON.stringify(body),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 && token) { session.set(''); throw new Error('Session expired. Please sign in again.'); }
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return raw ? res : res.json();
}

export const api = {
  login: (body) => call('/login', { method: 'POST', body }),
  me: () => call('/me'),
  subjects: () => call('/subjects'),
  students: () => call('/students'),
  addStudent: (body) => call('/students', { method: 'POST', body }),
  deleteStudent: (id) => call(`/students/${id}`, { method: 'DELETE' }),
  addNote: (body) => call('/notes', { method: 'POST', body }),
  markAttendance: (body) => call('/attendance', { method: 'POST', body }),
  log: () => call('/attendance/log'),
  reportCsv: async () => (await call('/report.csv', { raw: true })).blob(),
};
