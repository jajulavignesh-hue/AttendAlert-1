import { percent, risk, classesNeeded, canSkip } from '/shared/attendance.js';
import { api, session } from './api.js';
import { $, esc, badge, bar, toast, ask } from './ui.js';

const state = { user: null, subjects: [], students: [] };
const sum = (a) => a.reduce((x, y) => x + y, 0);
const pct = (s, i) => percent(s.att[i], s.held[i]);
const avg = (s) => percent(sum(s.att), sum(s.held));
const weak = (s) => state.subjects.filter((_, i) => s.held[i] > 0 && pct(s, i) < 75).map((x) => x.name).join(', ') || 'none';
const isMentor = () => state.user?.role === 'mentor';

// ---------- rendering ----------
function rosterTable(rows, withDelete = false) {
  if (!rows.length) return '<div class="empty">No students found.</div>';
  return `<table><thead><tr><th>Student</th><th>Roll number</th><th>Overall</th><th>Risk level</th>${withDelete ? '<th></th>' : ''}</tr></thead><tbody>${
    rows.map((s) => `<tr><td><b>${esc(s.name)}</b></td><td>${esc(s.roll)}</td><td>${bar(avg(s))}</td><td>${badge(risk(avg(s)))}</td>${
      withDelete ? `<td><button class="btn danger small" data-action="remove" data-id="${s.id}">Remove</button></td>` : ''}</tr>`).join('')}</tbody></table>`;
}

function renderDashboard() {
  const level = (s) => risk(avg(s));
  const safe = state.students.filter((s) => level(s) === 'Safe').length;
  const warn = state.students.filter((s) => level(s) === 'Warning').length;
  $('stats').innerHTML = [['Total students', state.students.length, 'Active roster'], ['Safe students', safe, '75% and above'],
    ['Warning', warn, '65% - 74.9%'], ['Critical shortage', state.students.length - safe - warn, 'Below 65%']]
    .map((x) => `<div class="card"><div class="stathead">${x[0]}</div><div class="stat">${x[1]}</div><div class="statnote">${x[2]}</div></div>`).join('');
  const at = state.students.filter((s) => level(s) !== 'Safe').sort((a, b) => avg(a) - avg(b)).slice(0, 5);
  $('dashAlerts').innerHTML = at.length ? at.map((s) => `<div class="alert"><span><b>${esc(s.name)}</b><br><small class="muted">${esc(s.roll)} · ${avg(s)}% attendance</small></span>${badge(level(s))}</div>`).join('')
    : '<div class="empty">No students currently at risk.</div>';
  $('subjectSummary').innerHTML = state.subjects.map((sub, i) => {
    const p = Math.floor(state.students.reduce((a, s) => a + pct(s, i), 0) / (state.students.length || 1));
    return `<div class="subjectrow"><span>${esc(sub.name)}</span><span>${bar(p)}</span></div>`;
  }).join('');
  $('dashTable').innerHTML = rosterTable(state.students.slice(0, 6));
  const h = new Date().getHours();
  $('greeting').textContent = `Good ${h < 12 ? 'morning' : h < 17 ? 'afternoon' : 'evening'}, Mentor 👋`;
}

function renderStudents() {
  const q = $('studentSearch').value.toLowerCase(), r = $('studentRisk').value;
  $('studentTable').innerHTML = rosterTable(state.students.filter((s) =>
    (s.name.toLowerCase().includes(q) || s.roll.toLowerCase().includes(q)) && (r === 'All' || risk(avg(s)) === r)), true);
}

const periods = () => {
  const start = Number($('attStartPeriod').value), count = Number($('attPeriodCount').value);
  return Array.from({ length: count }, (_, i) => start + i);
};

function renderAttendance() {
  const idx = $('attSubject').selectedIndex, ps = periods();
  const maxStart = $('attPeriodCount').value === '2' ? 7 : 8;
  [...$('attStartPeriod').options].forEach((o) => (o.disabled = Number(o.value) > maxStart));
  if (Number($('attStartPeriod').value) > maxStart) $('attStartPeriod').value = String(maxStart);
  $('attTable').innerHTML = `<table><thead><tr><th>Student</th><th>Roll number</th><th>Current %</th>${ps.map((p) => `<th>Period ${p} status</th>`).join('')}</tr></thead><tbody>${
    state.students.map((s) => `<tr><td><b>${esc(s.name)}</b></td><td>${esc(s.roll)}</td><td>${pct(s, idx)}%</td>${ps.map((p) =>
      `<td><select class="field" data-student="${s.id}" data-period="${p}" aria-label="${esc(s.name)} period ${p}"><option>Present</option><option>Absent</option><option>Late</option></select></td>`).join('')}</tr>`).join('')}</tbody></table>`;
}

function renderAlerts() {
  const at = state.students.filter((s) => risk(avg(s)) !== 'Safe').sort((a, b) => avg(a) - avg(b));
  $('alertList').innerHTML = at.length ? at.map((s) => `<div class="alert"><span><b>${esc(s.name)}</b> — ${avg(s)}% overall<br>
    <small class="muted">${esc(s.roll)} · ${risk(avg(s))} · Mentor follow-up recommended</small><br>
    <small>Below 75% in: ${esc(weak(s))} · ${s.notes} note(s) logged</small><br>
    <button class="btn secondary small" style="margin-top:8px" data-action="note" data-id="${s.id}">Log mentoring intervention</button></span>${badge(risk(avg(s)))}</div>`).join('')
    : '<div class="empty">Great! No at-risk students.</div>';
}

function fillSelectors() {
  const keep = (id, html) => { const el = $(id), v = el.value; el.innerHTML = html; if (v && [...el.options].some((o) => o.value === v)) el.value = v; };
  const students = state.students.map((s) => `<option value="${s.id}">${esc(s.name)} (${esc(s.roll)})</option>`).join('');
  keep('recStudent', students);
  keep('portalStudent', students);
  const subs = state.subjects.map((s, i) => `<option value="${i}">${esc(s.name)}</option>`).join('');
  keep('recSubject', subs);
  if (!$('attSubject').options.length) $('attSubject').innerHTML = state.subjects.map((s) => `<option>${esc(s.name)}</option>`).join('');
}

function renderRecovery() {
  const s = state.students.find((x) => x.id === Number($('recStudent').value));
  if (!s) { $('recoveryResult').innerHTML = ''; return; }
  const i = Number($('recSubject').value), a = s.att[i], h = s.held[i];
  const need = classesNeeded(a, h), skip = canSkip(a, h), name = state.subjects[i].name;
  $('recoveryResult').innerHTML = `<div class="cards">
    <div class="card"><div class="stathead">Current attendance</div><div class="stat">${pct(s, i)}%</div></div>
    <div class="card"><div class="stathead">Classes attended</div><div class="stat">${a} / ${h}</div></div>
    <div class="card"><div class="stathead">Consecutive classes needed</div><div class="stat amber">${need}</div></div>
    <div class="card"><div class="stathead">Classes safe to miss</div><div class="stat green">${skip}</div></div></div>
    <div class="notice">${need === 0 ? `${esc(s.name)} meets the 75% threshold in ${esc(name)} and can miss up to ${skip} more class(es) and stay eligible.`
      : `If ${esc(s.name)} attends the next ${need} consecutive ${esc(name)} classes, attendance will reach at least 75%.`}</div>`;
}

function renderPortal() {
  const s = state.students.find((x) => x.id === Number($('portalStudent').value)) || state.students[0];
  if (!s) { $('portalContent').innerHTML = '<div class="empty">No data yet.</div>'; return; }
  $('portalContent').innerHTML = `<h2>${esc(s.name)}</h2><p class="muted">${esc(s.roll)}</p>
    <div class="cards"><div class="card"><div class="stathead">Overall attendance</div><div class="stat">${avg(s)}%</div>${badge(risk(avg(s)))}</div>
    <div class="card"><div class="stathead">Subjects tracked</div><div class="stat">${state.subjects.length}</div></div></div>
    ${state.subjects.map((sub, i) => `<div class="subjectrow"><span>${esc(sub.name)}<br><small class="muted">${
      classesNeeded(s.att[i], s.held[i]) ? `Attend next ${classesNeeded(s.att[i], s.held[i])} to reach 75%` : `Can miss ${canSkip(s.att[i], s.held[i])} and stay eligible`}</small></span>
      <span>${bar(pct(s, i))} ${badge(risk(pct(s, i)))}</span></div>`).join('')}`;
}

async function renderLog() {
  if (!isMentor()) return;
  const log = await api.log();
  $('logTable').innerHTML = log.length ? `<h3>Attendance history</h3><table><thead><tr><th>Date</th><th>Subject</th><th>Periods</th><th>Absent</th></tr></thead><tbody>${
    log.map((l) => `<tr><td>${esc(l.date)}</td><td>${esc(l.subject)}</td><td>${l.periods.join(', ')}</td><td>${l.absent.length ? esc(l.absent.join(', ')) : 'None'}</td></tr>`).join('')}</tbody></table>`
    : '<div class="empty">No attendance saved yet.</div>';
}

async function refresh() {
  state.students = await api.students();
  fillSelectors();
  if (isMentor()) { renderDashboard(); renderStudents(); renderAttendance(); renderAlerts(); renderRecovery(); await renderLog(); }
  renderPortal();
}

// ---------- actions (wired by data-action attributes) ----------
const actions = {
  showPage(id) {
    if (!isMentor() && id !== 'student') return;
    document.querySelectorAll('.page').forEach((p) => p.classList.toggle('hidden', p.id !== id));
    document.querySelectorAll('.nav button[data-page]').forEach((b) => b.classList.toggle('active', b.dataset.page === id));
    $('topTitle').textContent = document.querySelector(`button[data-page="${id}"]`).textContent.trim().replace(/^[^\w]+/, '');
  },
  markAll(value) { document.querySelectorAll('#attTable select').forEach((el) => (el.value = value)); },
  async saveAttendance() {
    const records = [...document.querySelectorAll('#attTable select')].map((el) => ({ studentId: Number(el.dataset.student), period: Number(el.dataset.period), status: el.value }));
    const res = await api.markAttendance({ date: $('attDate').value, subjectId: $('attSubject').selectedIndex + 1, periods: periods(), records });
    toast(`Attendance saved (${res.saved} records).`);
    await refresh();
  },
  async addStudent() {
    const v = await ask('Add student', [{ label: 'Full name', name: 'name', attrs: 'maxlength="60"' }, { label: 'Roll number', name: 'roll', attrs: 'maxlength="20"' },
      { label: 'Initial password (min 8 characters)', name: 'password', type: 'password', attrs: 'minlength="8"' }]);
    if (!v) return;
    await api.addStudent(v);
    toast(`${v.name} added. They can sign in with their roll number.`);
    await refresh();
  },
  async remove(_, el) {
    const s = state.students.find((x) => x.id === Number(el.dataset.id));
    if (!s || !confirm(`Remove ${s.name} and all of their attendance records?`)) return;
    await api.deleteStudent(s.id);
    toast(`${s.name} removed.`);
    await refresh();
  },
  async note(_, el) {
    const s = state.students.find((x) => x.id === Number(el.dataset.id));
    const v = await ask(`Mentoring note for ${s.name}`, [{ label: 'Note', name: 'note', attrs: 'minlength="3" maxlength="500"' }]);
    if (!v) return;
    await api.addNote({ studentId: s.id, note: v.note });
    toast('Mentoring intervention recorded.');
    await refresh();
  },
  async exportCSV() {
    const a = Object.assign(document.createElement('a'), { href: URL.createObjectURL(await api.reportCsv()), download: 'attendalert-report.csv' });
    a.click();
    URL.revokeObjectURL(a.href);
  },
  print: () => window.print(),
  logout() { session.set(''); location.reload(); },
};

// Runs an async action and reports failures as a toast instead of an alert().
const guard = (fn) => async (...args) => {
  try { await fn(...args); } catch (e) { toast(e.message, true); if (/^Session expired/.test(e.message)) setTimeout(() => location.reload(), 1200); }
};

document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-action]');
  if (el) guard(actions[el.dataset.action])(el.dataset.arg, el);
});
document.querySelectorAll('.nav button[data-page]').forEach((b) => b.addEventListener('click', () => actions.showPage(b.dataset.page)));
$('studentSearch').addEventListener('input', renderStudents);
$('studentRisk').addEventListener('change', renderStudents);
$('recStudent').addEventListener('change', renderRecovery);
$('recSubject').addEventListener('change', renderRecovery);
$('portalStudent').addEventListener('change', renderPortal);
['attSubject', 'attStartPeriod', 'attPeriodCount'].forEach((id) => $(id).addEventListener('change', renderAttendance));
$('attDate').value = new Date().toISOString().slice(0, 10);
$('attDate').max = $('attDate').value;

// ---------- sign in / start ----------
async function start() {
  state.subjects = await api.subjects();
  $('loginScreen').classList.add('hidden');
  $('appLayout').classList.remove('hidden');
  document.querySelector('.profile span').textContent = isMentor() ? 'Mentor Workspace' : 'Student Portal';
  document.querySelector('.avatar').textContent = state.user.username[0].toUpperCase();
  document.querySelectorAll('.nav button[data-page]').forEach((b) => b.classList.toggle('hidden', !isMentor() && b.dataset.page !== 'student'));
  $('portalStudent').disabled = !isMentor();
  await refresh();
  actions.showPage(isMentor() ? 'dashboard' : 'student');
}

$('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const res = await api.login({ username: $('loginUsername').value.trim(), password: $('loginPassword').value });
    session.set(res.token);
    state.user = res;
    $('loginPassword').value = '';
    $('loginError').textContent = '';
    await start();
  } catch (err) { $('loginError').textContent = err.message; }
});

if (session.get()) {
  api.me().then((u) => { state.user = u; return start(); }).catch(() => session.set(''));
}
