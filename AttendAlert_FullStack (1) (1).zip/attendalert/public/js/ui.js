// Presentation helpers: escaping, badges, toasts and the modal form.
export const $ = (id) => document.getElementById(id);

export const esc = (v) => String(v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const badge = (r) => `<span class="badge ${r.toLowerCase()}">${r}</span>`;
export const bar = (p) => {
  const color = p >= 75 ? 'var(--green)' : p >= 65 ? 'var(--amber)' : 'var(--red)';
  return `<span class="bar"><i style="width:${Math.min(100, p)}%;background:${color}"></i></span>${p}%`;
};

let timer;
export function toast(message, isError = false) {
  const el = $('toast');
  el.textContent = message;
  el.className = `show${isError ? ' error' : ''}`;
  clearTimeout(timer);
  timer = setTimeout(() => (el.className = ''), 3800);
}

/** Opens the modal dialog; resolves with the entered values, or null if cancelled. */
export function ask(title, fields) {
  return new Promise((resolve) => {
    const dlg = $('dlg');
    $('dlgTitle').textContent = title;
    $('dlgFields').innerHTML = fields.map((f) =>
      `<label>${esc(f.label)}<input class="field login-field" name="${esc(f.name)}" type="${f.type || 'text'}" ${f.attrs || ''} required></label>`).join('');
    dlg.returnValue = '';
    dlg.addEventListener('close', () => resolve(dlg.returnValue === 'ok' ? Object.fromEntries(new FormData($('dlgForm'))) : null), { once: true });
    dlg.showModal();
  });
}
