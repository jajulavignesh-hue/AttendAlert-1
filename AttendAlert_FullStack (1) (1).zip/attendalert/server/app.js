// Thin HTTP layer: routing, security headers and error mapping. Rules live in service.js.
import express from 'express';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
import { HttpError } from './service.js';

const ROOT = fileURLToPath(new URL('..', import.meta.url)); // handles spaces and Windows drive letters

export function createApp(service) {
  const app = express();
  app.disable('x-powered-by');
  app.use((req, res, next) => {
    res.set({
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
      'Referrer-Policy': 'no-referrer',
      'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'",
    });
    next();
  });
  app.use(express.json({ limit: '50kb' }));

  const fail = (res, e) => {
    if (e instanceof HttpError) return res.status(e.status).json({ error: e.message });
    console.error(e);
    return res.status(500).json({ error: 'Internal server error' });
  };
  // route(roles, handler): authenticates, authorises, runs handler(req, user), maps errors.
  const route = (roles, handler) => (req, res) => {
    try {
      const user = roles ? service.authenticate(req.headers.authorization, ...roles) : null;
      handler(req, res, user);
    } catch (e) { fail(res, e); }
  };
  const MENTOR = ['mentor'];
  const ANY = ['mentor', 'student'];
  const id = (req) => Number(req.params.id);

  app.post('/api/login', route(null, (req, res) => res.json(service.login(req.body, req.ip))));
  app.get('/api/me', route(ANY, (req, res, u) => res.json({ username: u.username, role: u.role, studentId: u.studentId })));
  app.get('/api/subjects', route(ANY, (req, res) => res.json(service.subjects())));
  app.get('/api/students', route(ANY, (req, res, u) => res.json(service.listStudents(u))));
  app.post('/api/students', route(MENTOR, (req, res) => res.status(201).json(service.addStudent(req.body))));
  app.delete('/api/students/:id', route(MENTOR, (req, res) => res.json(service.deleteStudent(id(req)))));
  app.get('/api/students/:id/notes', route(MENTOR, (req, res) => res.json(service.listNotes(id(req)))));
  app.post('/api/notes', route(MENTOR, (req, res) => res.status(201).json(service.addNote(req.body))));
  app.post('/api/attendance', route(MENTOR, (req, res) => res.status(201).json(service.markAttendance(req.body))));
  app.get('/api/attendance/log', route(MENTOR, (req, res) => res.json(service.attendanceLog())));
  app.get('/api/report.csv', route(MENTOR, (req, res) => res.type('text/csv').attachment('attendalert-report.csv').send(service.csvReport())));
  app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

  app.use('/shared', express.static(join(ROOT, 'shared')));
  app.use(express.static(join(ROOT, 'public')));
  // Malformed JSON and other middleware errors
  app.use((err, req, res, next) => res.status(err.status === 413 ? 413 : 400).json({ error: 'Invalid request' }));
  return app;
}
