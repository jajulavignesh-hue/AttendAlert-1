// SQLite schema + demo seed (uses Node's built-in node:sqlite, no native build step).
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { hashPassword } from './auth.js';

export const SUBJECTS = ['Mathematics', 'Data Structures', 'Database Systems', 'Computer Networks', 'Web Development'];

const SCHEMA = `
CREATE TABLE IF NOT EXISTS subjects (id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, roll TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK (role IN ('mentor','student')),
  student_id INTEGER REFERENCES students(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS attendance (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  subject_id INTEGER NOT NULL REFERENCES subjects(id),
  date TEXT NOT NULL, period INTEGER NOT NULL CHECK (period BETWEEN 1 AND 8),
  status TEXT NOT NULL CHECK (status IN ('Present','Absent','Late')),
  UNIQUE (student_id, subject_id, date, period));
CREATE TABLE IF NOT EXISTS notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  note TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_att_student ON attendance(student_id, subject_id);
`;

export function openDb(file = ':memory:') {
  if (file !== ':memory:') mkdirSync(dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec(SCHEMA);
  const ins = db.prepare('INSERT OR IGNORE INTO subjects (id, name) VALUES (?, ?)');
  SUBJECTS.forEach((name, i) => ins.run(i + 1, name));
  return db;
}

const DEMO = [
  ['Rahul Verma', '23A91A0001', [12, 9, 14, 11, 13]], ['Priya Sharma', '23A91A0002', [18, 19, 17, 18, 19]],
  ['Arjun Reddy', '23A91A0003', [15, 14, 16, 15, 14]], ['Sneha Rao', '23A91A0004', [13, 12, 14, 13, 12]],
  ['Kiran Kumar', '23A91A0005', [10, 11, 9, 10, 12]], ['Ananya Das', '23A91A0006', [19, 18, 19, 20, 18]],
  ['Vikram Singh', '23A91A0007', [8, 10, 9, 11, 8]], ['Meera Patel', '23A91A0008', [16, 17, 15, 16, 17]],
  ['Sai Teja', '23A91A0009', [14, 13, 14, 15, 13]], ['Divya Nair', '23A91A0010', [20, 19, 18, 19, 20]],
  ['Rohit Jain', '23A91A0011', [11, 12, 10, 12, 11]], ['Pooja Reddy', '23A91A0012', [17, 16, 18, 17, 16]],
];

/** Seeds demo data once (20 past classes per subject). Demo passwords: mentor123 / student123. */
export function seed(db) {
  if (db.prepare('SELECT COUNT(*) c FROM users').get().c > 0) return;
  const addStudent = db.prepare('INSERT INTO students (name, roll) VALUES (?, ?)');
  const addUser = db.prepare('INSERT INTO users (username, password_hash, role, student_id) VALUES (?, ?, ?, ?)');
  const addAtt = db.prepare('INSERT INTO attendance (student_id, subject_id, date, period, status) VALUES (?, ?, ?, 1, ?)');
  const studentHash = hashPassword('student123');
  db.exec('BEGIN');
  try {
    addUser.run('mentor', hashPassword('mentor123'), 'mentor', null);
    DEMO.forEach(([name, roll, attended], idx) => {
      const sid = Number(addStudent.run(name, roll).lastInsertRowid);
      addUser.run(roll.toLowerCase(), studentHash, 'student', sid);
      if (idx === 0) addUser.run('student', studentHash, 'student', sid);
      attended.forEach((att, s) => {
        for (let k = 0; k < 20; k++) {
          const d = new Date(Date.now() - (20 - k) * 86400000).toISOString().slice(0, 10);
          addAtt.run(sid, s + 1, d, k < 20 - att ? 'Absent' : 'Present');
        }
      });
    });
    db.exec('COMMIT');
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  }
}
