import { openDb, seed } from './db.js';
import { createService } from './service.js';
import { createApp } from './app.js';

const db = openDb(process.env.DB_FILE || 'data/attendalert.db');
seed(db);
const app = createApp(createService(db, { secret: process.env.TOKEN_SECRET }));
const port = Number(process.env.PORT) || 3000;
app.listen(port, () => console.log(`AttendAlert running at http://localhost:${port}`));
