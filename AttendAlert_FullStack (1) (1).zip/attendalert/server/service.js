// Business logic: validation, authorisation and data access. No Express here,
// so every rule can be unit-tested directly against an in-memory SQLite database.
import { randomBytes } from 'node:crypto';
import { hashPassword, verifyPassword, signToken, verifyToken } from './auth.js';
import { percent, risk } from '../shared/attendance.js';

export class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const bad = (m) => new HttpError(400, m);
const STATUSES = ['Present', 'Absent', 'Late'];
const DUMMY_HASH = hashPassword('timing-equaliser');
const MAX_FAILS = 5;
const LOCK_MS = 15 * 60 * 1000;

export function createService(db, { secret = randomBytes(32).toString('hex'), now = () => new Date() } = {}) {
  const fails = new Map();
  const today = () => now().toISOString().slice(0, 10);
  const subjects = () => db.prepare('SELECT id, name FROM subjects ORDER BY id').all();
  const isUnique = (e) => /UNIQUE/i.test(String(e.message));

  function login(body, ip = 'local') {
    const { username, password } = body || {};
    if (typeof username !== 'string' || typeof password !== 'string' || !username || !password || username.length > 64 || password.length > 128)
      throw bad('Username and password are required');
    const key = `${ip}|${username.toLowerCase()}`;
    const f = fails.get(key);
    if (f && f.count >= MAX_FAILS && Date.now() - f.since < LOCK_MS)
      throw new HttpError(429, 'Too many failed attempts. Try again in 15 minutes.');
    const u = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    const ok = u ? verifyPassword(password, u.password_hash) : (verifyPassword(password, DUMMY_HASH), false);
    if (!ok) {
      const fresh = !f || Date.now() - f.since >= LOCK_MS;
      fails.set(key, { count: fresh ? 1 : f.count + 1, since: fresh ? Date.now() : f.since });
      throw new HttpError(401, 'Incorrect username or password');
    }
    fails.delete(key);
    const user = { sub: u.id, username: u.username, role: u.role, studentId: u.student_id };
    return { token: signToken(user, secret), ...publicUser(user) };
  }
  const publicUser = (u) => ({ username: u.username, role: u.role, studentId: u.studentId });

  /** Returns the token payload or throws 401 / 403. */
  function authenticate(header, ...roles) {
    const m = /^Bearer (.+)$/.exec(header || '');
    const user = m && verifyToken(m[1], secret);
    if (!user) throw new HttpError(401, 'Please sign in');
    if (roles.length && !roles.includes(user.role)) throw new HttpError(403, 'You do not have permission to do that');
    return user;
  }

  function listStudents(user) {
    const own = user.role === 'student';
    const rows = db.prepare(`
      SELECT s.id, s.name, s.roll, a.subject_id sid, COUNT(a.id) held,
             COALESCE(SUM(a.status != 'Absent'), 0) att,
             (SELECT COUNT(*) FROM notes n WHERE n.student_id = s.id) notes
      FROM students s LEFT JOIN attendance a ON a.student_id = s.id
      ${own ? 'WHERE s.id = ?' : ''} GROUP BY s.id, a.subject_id ORDER BY s.id`).all(...(own ? [user.studentId] : []));
    const n = subjects().length, map = new Map();
    for (const r of rows) {
      if (!map.has(r.id)) map.set(r.id, { id: r.id, name: r.name, roll: r.roll, notes: r.notes, held: Array(n).fill(0), att: Array(n).fill(0) });
      if (r.sid) { const s = map.get(r.id); s.held[r.sid - 1] = r.held; s.att[r.sid - 1] = r.att; }
    }
    return [...map.values()];
  }

  function addStudent({ name, roll, password } = {}) {
    if (typeof name !== 'string' || !/^[\p{L} .'-]{2,60}$/u.test(name.trim())) throw bad('Name must be 2-60 letters');
    if (typeof roll !== 'string' || !/^[A-Za-z0-9]{4,20}$/.test(roll.trim())) throw bad('Roll number must be 4-20 letters or digits');
    if (typeof password !== 'string' || password.length < 8 || password.length > 128) throw bad('Initial password must be at least 8 characters');
    name = name.trim(); roll = roll.trim().toUpperCase();
    db.exec('BEGIN');
    try {
      const id = Number(db.prepare('INSERT INTO students (name, roll) VALUES (?, ?)').run(name, roll).lastInsertRowid);
      db.prepare("INSERT INTO users (username, password_hash, role, student_id) VALUES (?, ?, 'student', ?)").run(roll.toLowerCase(), hashPassword(password), id);
      db.exec('COMMIT');
      return { id, name, roll };
    } catch (e) {
      db.exec('ROLLBACK');
      if (isUnique(e)) throw new HttpError(409, 'That roll number already exists');
      throw e;
    }
  }

  function deleteStudent(id) {
    if (!Number.isInteger(id)) throw bad('Invalid student id');
    if (db.prepare('DELETE FROM students WHERE id = ?').run(id).changes === 0) throw new HttpError(404, 'Student not found');
    return { deleted: id };
  }

  function markAttendance(body) {
    const { date, subjectId, periods, records } = body || {};
    if (typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date) || new Date(`${date}T00:00:00Z`).toISOString().slice(0, 10) !== date)
      throw bad('A valid date (YYYY-MM-DD) is required');
    if (date > today()) throw bad('Attendance cannot be marked for a future date');
    if (!subjects().some((s) => s.id === subjectId)) throw bad('Unknown subject');
    if (!Array.isArray(periods) || periods.length < 1 || periods.length > 2 || !periods.every((p) => Number.isInteger(p) && p >= 1 && p <= 8) || (periods.length === 2 && periods[1] !== periods[0] + 1))
      throw bad('Choose 1 or 2 consecutive periods between 1 and 8');
    const ids = db.prepare('SELECT id FROM students').all().map((r) => r.id);
    if (!ids.length) throw bad('Add students before marking attendance');
    if (!Array.isArray(records) || records.length !== ids.length * periods.length) throw bad('A status is required for every student and period');
    const seen = new Set();
    for (const r of records) {
      const k = `${r?.studentId}-${r?.period}`;
      if (!ids.includes(r?.studentId) || !periods.includes(r?.period) || !STATUSES.includes(r?.status) || seen.has(k)) throw bad('Invalid attendance record');
      seen.add(k);
    }
    const ins = db.prepare('INSERT INTO attendance (student_id, subject_id, date, period, status) VALUES (?, ?, ?, ?, ?)');
    db.exec('BEGIN');
    try {
      for (const r of records) ins.run(r.studentId, subjectId, date, r.period, r.status);
      db.exec('COMMIT');
      return { saved: records.length };
    } catch (e) {
      db.exec('ROLLBACK');
      if (isUnique(e)) throw new HttpError(409, 'Attendance for this subject, date and period is already saved');
      throw e;
    }
  }

  function attendanceLog() {
    return db.prepare(`
      SELECT a.date, sub.name subject, GROUP_CONCAT(DISTINCT a.period) periods,
             GROUP_CONCAT(DISTINCT CASE WHEN a.status = 'Absent' THEN s.name END) absent
      FROM attendance a JOIN students s ON s.id = a.student_id JOIN subjects sub ON sub.id = a.subject_id
      GROUP BY a.date, a.subject_id ORDER BY a.date DESC, a.subject_id LIMIT 40`).all()
      .map((r) => ({ date: r.date, subject: r.subject, periods: r.periods.split(',').map(Number), absent: r.absent ? r.absent.split(',') : [] }));
  }

  function addNote({ studentId, note } = {}) {
    if (typeof note !== 'string' || note.trim().length < 3 || note.length > 500) throw bad('Note must be 3-500 characters');
    if (!Number.isInteger(studentId) || !db.prepare('SELECT 1 FROM students WHERE id = ?').get(studentId)) throw new HttpError(404, 'Student not found');
    db.prepare('INSERT INTO notes (student_id, note) VALUES (?, ?)').run(studentId, note.trim());
    return { saved: true };
  }
  const listNotes = (id) => db.prepare('SELECT note, created_at date FROM notes WHERE student_id = ? ORDER BY id DESC').all(id);

  // Spreadsheet-safe CSV: quotes escaped, leading = + - @ neutralised (CSV/formula injection).
  const cell = (v) => { const s = String(v); return `"${(/^[=+\-@\t\r]/.test(s) ? `'${s}` : s).replaceAll('"', '""')}"`; };
  function csvReport() {
    const subs = subjects();
    const lines = [['Name', 'Roll Number', 'Subject', 'Classes Held', 'Classes Attended', 'Attendance %', 'Risk']];
    for (const s of listStudents({ role: 'mentor' }))
      subs.forEach((sub, i) => { const p = percent(s.att[i], s.held[i]); lines.push([s.name, s.roll, sub.name, s.held[i], s.att[i], p, risk(p)]); });
    return lines.map((r) => r.map(cell).join(',')).join('\n');
  }

  return { login, authenticate, subjects, listStudents, addStudent, deleteStudent, markAttendance, attendanceLog, addNote, listNotes, csvReport };
}
