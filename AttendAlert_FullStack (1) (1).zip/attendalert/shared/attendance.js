// Pure attendance rules shared by the server, the browser and the tests.
// All maths uses integers where possible so 74.99% is never shown as 75%.
export const THRESHOLD = 75;
export const WARNING = 65;

/** Percentage rounded DOWN to 1 decimal (74.96 -> 74.9, never 75). */
export const percent = (attended, held) =>
  held > 0 ? Math.floor((attended * 1000) / held) / 10 : 0;

export const risk = (p) => (p >= THRESHOLD ? 'Safe' : p >= WARNING ? 'Warning' : 'Critical');

/** Consecutive classes to attend to reach 75%: (a+x)/(h+x) >= 3/4  =>  x >= 3h - 4a. */
export const classesNeeded = (attended, held) => Math.max(0, 3 * held - 4 * attended);

/** Classes that can be missed while staying at or above 75%: a/(h+x) >= 3/4. */
export const canSkip = (attended, held) =>
  held > 0 ? Math.max(0, Math.floor((4 * attended - 3 * held) / 3)) : 0;
