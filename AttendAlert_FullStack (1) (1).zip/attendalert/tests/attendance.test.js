import test from 'node:test';
import assert from 'node:assert/strict';
import { percent, risk, classesNeeded, canSkip } from '../shared/attendance.js';

test('percent rounds down so 74.96% is never shown as 75%', () => {
  assert.equal(percent(15, 20), 75);
  assert.equal(percent(1499, 2000), 74.9);
  assert.equal(percent(0, 0), 0);
});

test('risk tiers use the 75 / 65 boundaries', () => {
  assert.equal(risk(75), 'Safe');
  assert.equal(risk(74.9), 'Warning');
  assert.equal(risk(65), 'Warning');
  assert.equal(risk(64.9), 'Critical');
});

test('classesNeeded: attending that many consecutive classes reaches 75%', () => {
  for (let held = 1; held <= 40; held++)
    for (let att = 0; att <= held; att++) {
      const x = classesNeeded(att, held);
      assert.ok((att + x) * 4 >= (held + x) * 3, `reach 75% for ${att}/${held}`);
      if (x > 0) assert.ok((att + x - 1) * 4 < (held + x - 1) * 3, `${x} is minimal for ${att}/${held}`);
    }
});

test('canSkip: skipping that many stays >= 75%, one more drops below', () => {
  for (let held = 1; held <= 40; held++)
    for (let att = 0; att <= held; att++) {
      const x = canSkip(att, held);
      if (att * 4 >= held * 3) {
        assert.ok(att * 4 >= (held + x) * 3);
        assert.ok(att * 4 < (held + x + 1) * 3);
      } else assert.equal(x, 0);
    }
});
