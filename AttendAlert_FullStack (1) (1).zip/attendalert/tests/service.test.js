import test from 'node:test';
import assert from 'node:assert/strict';
import { openDb, seed } from '../server/db.js';
import { createService, HttpError } from '../server/service.js';
import { hashPassword, verifyPassword, signToken, verifyToken } from '../server/auth.js';
import { percent } from '../shared/attendance.js';

function setup() {
  const db = openDb(':memory:');
  seed(db);
  const svc = createService(db, { secret: 'test-secret' });
  const bearer = (u, p) => `Bearer ${svc.login({ username: u, password: p }).token}`;
  return { db, svc, mentor: bearer('mentor', 'mentor123') };
}
const status = (fn) => { try { fn(); return 200; } catch (e) { assert.ok(e instanceof HttpError, e.stack); return e.status; } };
const todayStr = () => new Date().toISOString().slice(0, 10);
const allPresent = (svc, periods) => svc.listStudents({ role: 'mentor' }).flatMap((s) => periods.map((period) => ({ studentId: s.id, period, status: 'Present' })));

test('passwords are hashed with scrypt and verify correctly', () => {
  const h = hashPassword('secret123');
  assert.ok(!h.includes('secret123'));
  assert.ok(verifyPassword('secret123', h));
  assert.ok(!verifyPassword('wrong', h));
  assert.notEqual(h, hashPassword('secret123'), 'salted');
});

test('tokens reject tampering and expiry', () => {
  const t = signToken({ sub: 1 }, 's');
  assert.equal(verifyToken(t, 's').sub, 1);
  assert.equal(verifyToken(t, 'other'), null);
  assert.equal(verifyToken(t.slice(0, -2) + 'xx', 's'), null);
  assert.equal(verifyToken(signToken({ sub: 1 }, 's', -10), 's'), null);
});

test('login: success, wrong password, unknown user, missing fields', () => {
  const { svc } = setup();
  assert.equal(svc.login({ username: 'mentor', password: 'mentor123' }).role, 'mentor');
  assert.equal(status(() => svc.login({ username: 'mentor', password: 'nope' })), 401);
  assert.equal(status(() => svc.login({ username: 'ghost', password: 'x' })), 401);
  assert.equal(status(() => svc.login({})), 400);
});

test('login locks out after 5 failed attempts', () => {
  const { svc } = setup();
  for (let i = 0; i < 5; i++) status(() => svc.login({ username: 'mentor', password: 'bad' }));
  assert.equal(status(() => svc.login({ username: 'mentor', password: 'mentor123' })), 429);
});

test('role-based access: students cannot use mentor endpoints or see others', () => {
  const { svc, mentor } = setup();
  const student = `Bearer ${svc.login({ username: '23A91A0003', password: 'student123' }).token}`;
  assert.equal(status(() => svc.authenticate(student, 'mentor')), 403);
  assert.equal(status(() => svc.authenticate(undefined)), 401);
  assert.equal(status(() => svc.authenticate('Bearer garbage')), 401);
  const me = svc.authenticate(student);
  const visible = svc.listStudents(me);
  assert.equal(visible.length, 1);
  assert.equal(visible[0].roll, '23A91A0003');
  assert.equal(svc.listStudents(svc.authenticate(mentor)).length, 12);
});

test('seed data matches the expected percentages', () => {
  const { svc } = setup();
  const rahul = svc.listStudents({ role: 'mentor' })[0];
  assert.deepEqual(rahul.att, [12, 9, 14, 11, 13]);
  assert.deepEqual(rahul.held, [20, 20, 20, 20, 20]);
  assert.equal(percent(rahul.att[1], rahul.held[1]), 45);
});

test('markAttendance updates held/attended; Late counts as attended', () => {
  const { svc } = setup();
  const before = svc.listStudents({ role: 'mentor' })[0];
  const records = allPresent(svc, [1, 2]);
  records[0].status = 'Absent'; // student 1, period 1
  records[1].status = 'Late';   // student 1, period 2
  assert.equal(svc.markAttendance({ date: todayStr(), subjectId: 1, periods: [1, 2], records }).saved, 24);
  const after = svc.listStudents({ role: 'mentor' })[0];
  assert.equal(after.held[0], before.held[0] + 2);
  assert.equal(after.att[0], before.att[0] + 1);
});

test('markAttendance rejects duplicates with 409 and changes nothing', () => {
  const { svc } = setup();
  const body = { date: todayStr(), subjectId: 2, periods: [3], records: allPresent(svc, [3]) };
  svc.markAttendance(body);
  const snapshot = JSON.stringify(svc.listStudents({ role: 'mentor' }));
  assert.equal(status(() => svc.markAttendance(body)), 409);
  assert.equal(JSON.stringify(svc.listStudents({ role: 'mentor' })), snapshot);
});

test('markAttendance validates date, subject, periods and records', () => {
  const { svc } = setup();
  const ok = { date: todayStr(), subjectId: 1, periods: [4], records: allPresent(svc, [4]) };
  const tomorrow = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  for (const patch of [
    { date: tomorrow }, { date: '2026-02-31' }, { date: 'yesterday' }, { subjectId: 99 },
    { periods: [0] }, { periods: [9] }, { periods: [1, 3] }, { periods: [1, 2, 3] }, { periods: 'x' },
    { records: [] }, { records: ok.records.slice(1) },
    { records: ok.records.map((r, i) => (i ? r : { ...r, status: 'Maybe' })) },
    { records: ok.records.map((r, i) => (i ? r : { ...r, studentId: 9999 })) },
  ]) assert.equal(status(() => svc.markAttendance({ ...ok, ...patch })), 400, JSON.stringify(patch).slice(0, 60));
  assert.equal(status(() => svc.markAttendance(null)), 400);
});

test('addStudent validates input, prevents duplicate rolls and creates a login', () => {
  const { svc } = setup();
  const good = { name: 'Asha Mehta', roll: '23a91a0099', password: 'longenough1' };
  assert.equal(svc.addStudent(good).roll, '23A91A0099');
  assert.equal(svc.login({ username: '23A91A0099', password: 'longenough1' }).role, 'student');
  assert.equal(status(() => svc.addStudent(good)), 409);
  for (const patch of [{ name: 'A' }, { name: '<script>x</script>' }, { name: "Robert'); DROP TABLE students;--" }, { roll: 'x y' }, { password: 'short' }])
    assert.equal(status(() => svc.addStudent({ ...good, roll: '23A91A0098', ...patch })), 400);
  assert.equal(svc.listStudents({ role: 'mentor' }).length, 13);
});

test('deleteStudent removes the student, their data and their login', () => {
  const { svc } = setup();
  assert.equal(svc.deleteStudent(1).deleted, 1);
  assert.equal(svc.listStudents({ role: 'mentor' }).length, 11);
  assert.equal(status(() => svc.login({ username: '23A91A0001', password: 'student123' })), 401);
  assert.equal(status(() => svc.deleteStudent(1)), 404);
  assert.equal(status(() => svc.deleteStudent('abc')), 400);
});

test('notes: validation and listing', () => {
  const { svc } = setup();
  svc.addNote({ studentId: 1, note: 'Spoke to student about attendance' });
  assert.equal(svc.listNotes(1).length, 1);
  assert.equal(svc.listStudents({ role: 'mentor' })[0].notes, 1);
  assert.equal(status(() => svc.addNote({ studentId: 1, note: 'x' })), 400);
  assert.equal(status(() => svc.addNote({ studentId: 999, note: 'valid note' })), 404);
});

test('attendance log lists absentees per date and subject', () => {
  const { svc } = setup();
  const records = allPresent(svc, [5]);
  records[0].status = 'Absent';
  svc.markAttendance({ date: todayStr(), subjectId: 3, periods: [5], records });
  const entry = svc.attendanceLog()[0];
  assert.equal(entry.date, todayStr());
  assert.equal(entry.subject, 'Database Systems');
  assert.deepEqual(entry.absent, ['Rahul Verma']);
});

test('CSV report neutralises formula injection and escapes quotes', () => {
  const { svc, db } = setup();
  db.prepare("UPDATE students SET name = '=HYPERLINK(\"x\")' WHERE id = 1").run();
  const csv = svc.csvReport();
  assert.ok(csv.startsWith('"Name","Roll Number"'));
  assert.ok(csv.includes('"\'=HYPERLINK(""x"")"'));
  assert.equal(csv.split('\n').length, 1 + 12 * 5);
});
